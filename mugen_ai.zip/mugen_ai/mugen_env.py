import gymnasium as gym
from gymnasium import spaces
import numpy as np
import time
import ctypes
import win32gui
import win32con
import win32api
from memory_reader import MugenMemoryReader

# キーコード定義
VK_LEFT = 0x25
VK_UP = 0x26
VK_RIGHT = 0x27
VK_DOWN = 0x28
VK_A = 0x41
VK_B = 0x42
VK_C = 0x43
VK_X = 0x58
VK_Y = 0x59
VK_Z = 0x5A
VK_RETURN = 0x0D

class MugenEnv(gym.Env):
    def __init__(self, player_side=1, process_id=None, instance_id=0):
        super(MugenEnv, self).__init__()
        
        self.player_side = player_side
        self.process_id = process_id
        self.instance_id = instance_id
        self.hwnd = None
        self.init_time = time.time()
        self.start_time = time.time()
        self.match_started_flag = False
        
        self.prev_my_x = 0
        self.prev_my_y = 0
        self.prev_opp_x = 0
        self.prev_opp_y = 0
        self.prev_my_life = 1000
        self.prev_opp_life = 1000
        
        # 1P/2Pそれぞれのキーマップ定義
        if self.player_side == 1:
            self.keys = {
                'UP': 0x57, 'DOWN': 0x53, 'LEFT': 0x41, 'RIGHT': 0x44, # WASD
                'A': 0x4A, 'B': 0x4B, 'C': 0x4C, 'X': 0x55, 'Y': 0x49, 'Z': 0x4F, 'START': 0x0D
            }
        else:
            # P2 Keymap (Arrows + Numpad)
            # テンキーはスキャンコードを送ることでNumLockの影響を回避する
            self.keys = {
                'UP': 0x26, # UP (Arrow Up)
                'DOWN': 0x28, # DOWN (Arrow Down)
                'LEFT': 0x25, # LEFT (Arrow Left)
                'RIGHT': 0x27, # RIGHT (Arrow Right)
                'A': 0x61, # A (Numpad 1)
                'B': 0x62, # B (Numpad 2)
                'C': 0x63, # C (Numpad 3)
                'X': 0x64, # X (Numpad 4)
                'Y': 0x65, # Y (Numpad 5)
                'Z': 0x66, # Z (Numpad 6)
                'START': 0x60 # START (Numpad 0)
            }

        # --- Ultimate Universal Fighting Game Action Set ---
        # Based on common MUGEN CMD patterns (Super moves, Special moves, and AI triggers)
        self.cmd_map = {
            # 0-3: Basic Movement
            0: [('hold', self.keys['LEFT'], 5)], # Walk Back
            1: [('hold', self.keys['RIGHT'], 5)], # Walk Forward
            2: [('hold', self.keys['UP'], 8)], # Jump
            3: [('hold', self.keys['DOWN'], 5)], # Crouch
            
            # 4-9: Basic Attacks
            4: [('tap', self.keys['A'])], 5: [('tap', self.keys['B'])], 6: [('tap', self.keys['C'])],
            7: [('tap', self.keys['X'])], 8: [('tap', self.keys['Y'])], 9: [('tap', self.keys['Z'])],
            
            # 10-13: Movement Macros
            10: [('tap', self.keys['RIGHT']), ('wait', 2), ('hold', self.keys['RIGHT'], 10)], # Dash Forward (FF)
            11: [('tap', self.keys['LEFT']), ('wait', 2), ('hold', self.keys['LEFT'], 10)],   # Dash Backward (BB)
            12: [('hold_multi', [self.keys['UP'], self.keys['RIGHT']], 10)], # Jump Forward
            13: [('hold_multi', [self.keys['UP'], self.keys['LEFT']], 10)],  # Jump Backward
            
            # 14-19: Common Special Motions (QCF, QCB, DP)
            14: [('hold', self.keys['DOWN'], 2), ('hold_multi', [self.keys['DOWN'], self.keys['RIGHT']], 2), ('hold', self.keys['RIGHT'], 2), ('tap', self.keys['A'])], # 236A
            15: [('hold', self.keys['DOWN'], 2), ('hold_multi', [self.keys['DOWN'], self.keys['RIGHT']], 2), ('hold', self.keys['RIGHT'], 2), ('tap', self.keys['X'])], # 236X
            16: [('hold', self.keys['DOWN'], 2), ('hold_multi', [self.keys['DOWN'], self.keys['LEFT']], 2), ('hold', self.keys['LEFT'], 2), ('tap', self.keys['A'])],  # 214A
            17: [('hold', self.keys['DOWN'], 2), ('hold_multi', [self.keys['DOWN'], self.keys['LEFT']], 2), ('hold', self.keys['LEFT'], 2), ('tap', self.keys['X'])],  # 214X
            18: [('hold', self.keys['RIGHT'], 2), ('hold', self.keys['DOWN'], 2), ('hold_multi', [self.keys['DOWN'], self.keys['RIGHT']], 2), ('tap', self.keys['A'])], # 623A
            19: [('hold', self.keys['RIGHT'], 2), ('hold', self.keys['DOWN'], 2), ('hold_multi', [self.keys['DOWN'], self.keys['RIGHT']], 2), ('tap', self.keys['X'])], # 623X
            
            # 20-23: Half-Circle Motions (HCF, HCB)
            20: [('hold', self.keys['LEFT'], 2), ('hold', self.keys['DOWN'], 2), ('hold', self.keys['RIGHT'], 2), ('tap', self.keys['A'])], # 41236A
            21: [('hold', self.keys['RIGHT'], 2), ('hold', self.keys['DOWN'], 2), ('hold', self.keys['LEFT'], 2), ('tap', self.keys['X'])], # 63214X
            
            # 24-27: Super Motions (Double QCF/QCB)
            24: [('hold', self.keys['DOWN'], 2), ('hold', self.keys['RIGHT'], 2), ('hold', self.keys['DOWN'], 2), ('hold', self.keys['RIGHT'], 2), ('tap', self.keys['A'])], # 236236A
            25: [('hold', self.keys['DOWN'], 2), ('hold', self.keys['RIGHT'], 2), ('hold', self.keys['DOWN'], 2), ('hold', self.keys['RIGHT'], 2), ('tap', self.keys['X'])], # 236236X
            26: [('hold', self.keys['DOWN'], 2), ('hold', self.keys['LEFT'], 2), ('hold', self.keys['DOWN'], 2), ('hold', self.keys['LEFT'], 2), ('tap', self.keys['A'])],  # 214214A
            27: [('hold', self.keys['DOWN'], 2), ('hold', self.keys['LEFT'], 2), ('hold', self.keys['DOWN'], 2), ('hold', self.keys['LEFT'], 2), ('tap', self.keys['X'])],  # 214214X
            
            # 28-31: AI Triggers / Complex Sequences (U, D, U, D...)
            28: [('tap', self.keys['UP']), ('wait', 1), ('tap', self.keys['DOWN']), ('wait', 1)] * 4 + [('tap', self.keys['A'])], # AI Trigger pattern
            29: [('tap', self.keys['UP']), ('wait', 1), ('tap', self.keys['DOWN']), ('wait', 1)] * 5 + [('tap', self.keys['B'])], # AI Trigger pattern
            30: [('hold', self.keys['DOWN'], 30), ('tap', self.keys['UP']), ('tap', self.keys['A'])], # Charge Down -> Up (28A)
            31: [('hold', self.keys['LEFT'], 30), ('tap', self.keys['RIGHT']), ('tap', self.keys['X'])], # Charge Back -> Forward (46X)
        }
        
        # MUGENウィンドウの特定
        self._find_window()
        
        self.action_space = spaces.Discrete(len(self.cmd_map))
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(16,), dtype=np.float32)

    def _find_window(self):
        import win32process
        import win32gui
        import win32con
        import win32api
        
        self.hwnd = None
        
        def enum_handler(hwnd, ctx):
            if win32gui.IsWindowVisible(hwnd):
                try:
                    _, pid = win32process.GetWindowThreadProcessId(hwnd)
                    if self.process_id and pid == self.process_id:
                        self.hwnd = hwnd
                except:
                    pass
        
        # ウィンドウが出るまで少し待つ
        for _ in range(20):
            win32gui.EnumWindows(enum_handler, None)
            if self.hwnd: break
            time.sleep(0.5)
            
        if self.hwnd:
            # P2環境 (instance_id >= 1000) の場合はウィンドウ位置をいじらない (P1と競合するため)
            if self.instance_id < 1000:
                try:
                    win32gui.ShowWindow(self.hwnd, win32con.SW_RESTORE)
                    sw = win32api.GetSystemMetrics(win32con.SM_CXSCREEN)
                    sh = win32api.GetSystemMetrics(win32con.SM_CYSCREEN)
                    w, h = 320, 240
                    positions = [(0, 0), (sw - w, 0), (0, sh - h - 40), (sw - w, sh - h - 40)]
                    pos = positions[self.instance_id % 4]
                    win32gui.SetWindowPos(self.hwnd, win32con.HWND_TOP, pos[0], pos[1], w, h, win32con.SWP_SHOWWINDOW)
                except:
                    pass

        # ウィンドウが見つかってからメモリリーダーを初期化
        self.memory = MugenMemoryReader(process_id=self.process_id)
        try:
            self.memory.scan_and_lock(timeout=10)
        except:
            pass

    def _send_key(self, key, duration_frames=1):
        if not self.hwnd: return
        
        try:
            scan_code = win32api.MapVirtualKey(key, 0)
            lparam_down = 0x00000001 | (scan_code << 16)
            lparam_up = 0xC0000001 | (scan_code << 16)
            
            if key in [0x26, 0x28, 0x25, 0x27, 0x2D, 0x2E, 0x21, 0x22, 0x23, 0x24]:
                lparam_down |= 0x01000000
                lparam_up |= 0x01000000

            win32api.PostMessage(self.hwnd, win32con.WM_ACTIVATE, win32con.WA_ACTIVE, 0)
            win32api.PostMessage(self.hwnd, win32con.WM_KEYDOWN, key, lparam_down)
            
            time.sleep(0.016 * duration_frames)
            
            win32api.PostMessage(self.hwnd, win32con.WM_KEYUP, key, lparam_up)
        except:
            pass

    def _send_multi_keys(self, keys, duration_frames=1):
        if not self.hwnd: return
        
        try:
            win32api.PostMessage(self.hwnd, win32con.WM_ACTIVATE, win32con.WA_ACTIVE, 0)
            
            for k in keys:
                scan_code = win32api.MapVirtualKey(k, 0)
                lparam_down = 0x00000001 | (scan_code << 16)
                win32api.PostMessage(self.hwnd, win32con.WM_KEYDOWN, k, lparam_down)
                
            time.sleep(0.016 * duration_frames)
            
            for k in keys:
                scan_code = win32api.MapVirtualKey(k, 0)
                lparam_up = 0xC0000001 | (scan_code << 16)
                win32api.PostMessage(self.hwnd, win32con.WM_KEYUP, k, lparam_up)
        except:
            pass

    def _execute_command(self, action_id):
        try:
            action_id = int(action_id)
        except:
            action_id = 0
        sequence = self.cmd_map.get(action_id, [])
        for cmd in sequence:
            type_ = cmd[0]
            if type_ == 'tap':
                self._send_key(cmd[1], 1)
            elif type_ == 'hold':
                self._send_key(cmd[1], cmd[2])
            elif type_ == 'hold_multi':
                self._send_multi_keys(cmd[1], cmd[2])
            elif type_ == 'wait':
                time.sleep(0.016 * cmd[1])

    def _normalize(self, val, max_val):
        if val is None or np.isnan(val) or np.isinf(val): return 0.0
        if max_val == 0: return 0.0
        return float(val) / float(max_val)

    def _get_obs(self):
        p1 = self.memory.get_player_state(1)
        p2 = self.memory.get_player_state(2)
        
        if not p1 or not p2: return np.zeros(16, dtype=np.float32)
            
        my_p = p1 if self.player_side == 1 else p2
        opp_p = p2 if self.player_side == 1 else p1
        
        # 速度の計算
        my_vx = my_p['x'] - self.prev_my_x
        my_vy = my_p['y'] - self.prev_my_y
        opp_vx = opp_p['x'] - self.prev_opp_x
        opp_vy = opp_p['y'] - self.prev_opp_y
        
        self.prev_my_x, self.prev_my_y = my_p['x'], my_p['y']
        self.prev_opp_x, self.prev_opp_y = opp_p['x'], opp_p['y']

        obs = np.array([
            self._normalize(my_p['life'], 1000.0),
            self._normalize(my_p['power'], 3000.0),
            self._normalize(my_p['x'] - opp_p['x'], 500.0), # 相対距離X
            self._normalize(my_p['y'] - opp_p['y'], 500.0), # 相対距離Y
            self._normalize(my_p['state'], 3000.0),
            self._normalize(my_vx, 50.0), # 自分の速度X
            self._normalize(my_vy, 50.0), # 自分の速度Y
            
            self._normalize(opp_p['life'], 1000.0),
            self._normalize(opp_p['power'], 3000.0),
            self._normalize(opp_p['state'], 3000.0),
            self._normalize(opp_vx, 50.0), # 相手の速度X
            self._normalize(opp_vy, 50.0), # 相手の速度Y
            
            # 追加の状況判断フラグ
            1.0 if my_p['life'] < 300 else 0.0, # ピンチフラグ
            1.0 if my_p['power'] >= 1000 else 0.0, # ゲージありフラグ
            self._normalize(my_p['x'], 1000.0), # 絶対位置X
            self._normalize(opp_p['x'], 1000.0)  # 相手の絶対位置X
        ], dtype=np.float32)
        
        return np.nan_to_num(obs, nan=0.0, posinf=1.0, neginf=-1.0)

    def step(self, action):
        try:
            # 起動からの絶対タイムアウト (フリーズ対策: 6分)
            if time.time() - self.init_time > 360:
                return self._get_obs(), 0, True, False, {}

            # ウィンドウが消えていたら即終了
            if self.hwnd and not win32gui.IsWindow(self.hwnd):
                return self._get_obs(), 0, True, False, {}

            self._execute_command(action)
            
            obs = self._get_obs()
            p1 = self.memory.get_player_state(1)
            p2 = self.memory.get_player_state(2)
            
            # 読み取り失敗時の処理
            if not p1 or not p2:
                if self.match_started_flag:
                    if not hasattr(self, '_fail_count'): self._fail_count = 0
                    self._fail_count += 1
                    if self._fail_count > 120:
                        return obs, 0, True, False, {}
                else:
                    # 開始前に失敗し続ける場合もタイムアウト (60秒)
                    if time.time() - self.init_time > 60:
                        return obs, 0, True, False, {}
                return obs, 0, False, False, {}
            
            self._fail_count = 0
                
            my_p = p1 if self.player_side == 1 else p2
            opp_p = p2 if self.player_side == 1 else p1
            
            # 試合開始判定
            if not self.match_started_flag:
                if 0 < my_p['life'] <= 5000 and 0 < opp_p['life'] <= 5000:
                    if not hasattr(self, '_stable_count'): self._stable_count = 0
                    self._stable_count += 1
                    if self._stable_count >= 10:
                        self.match_started_flag = True
                        self.start_time = time.time()
                        self._death_frames = 0
                else:
                    self._stable_count = 0
                    # 開始待ちタイムアウト
                    if time.time() - self.init_time > 60:
                        return obs, 0, True, False, {}

            damage_dealt = self.prev_opp_life - opp_p['life']
            damage_taken = self.prev_my_life - my_p['life']
            
            # 基本報酬: 与えたダメージ - 受けたダメージ
            reward = (damage_dealt - damage_taken) * 0.01
            
            # 接近報酬: 相手に近づくほどプラス (最大 0.005)
            dist = abs(my_p['x'] - opp_p['x'])
            dist_reward = max(0, (500 - dist) * 0.00001)
            reward += dist_reward
            
            # ガード報酬: 相手が攻撃中で、自分がガード状態(後退)ならプラス
            try:
                action_id = int(action)
            except:
                action_id = 0
            is_guarding = (self.player_side == 1 and action_id == 0) or (self.player_side == 2 and action_id == 1)
            if is_guarding and opp_p['state'] in [200, 400, 500]: # 攻撃ステートの例
                reward += 0.002

            self.prev_my_life = my_p['life']
            self.prev_opp_life = opp_p['life']
            
            # 終了判定
            terminated = False
            if self.match_started_flag:
                if time.time() - self.start_time > 300:
                    terminated = True
                
                if self.memory.is_match_over():
                    self._death_frames += 1
                else:
                    self._death_frames = 0
                
                if self._death_frames > 60:
                    terminated = True
                
                if time.time() - self.start_time < 15.0:
                    terminated = False
                
            return obs, reward, terminated, False, {}
        except Exception as e:
            print(f"Exception in step: {e}")
            import traceback
            traceback.print_exc()
            return self._get_obs(), 0, True, False, {}

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.match_started_flag = False
        self.start_time = time.time()
        
        # スタートボタン連打でイントロスキップ
        for _ in range(3):
            self._send_key(VK_RETURN, 1)
            time.sleep(0.1)
        
        obs = self._get_obs()
        p1 = self.memory.get_player_state(1)
        p2 = self.memory.get_player_state(2)
        if p1 and p2:
            my_p = p1 if self.player_side == 1 else p2
            opp_p = p2 if self.player_side == 1 else p1
            self.prev_my_life = my_p['life']
            self.prev_opp_life = opp_p['life']
            self.prev_my_x = my_p['x']
            self.prev_my_y = my_p['y']
            self.prev_opp_x = opp_p['x']
            self.prev_opp_y = opp_p['y']
        return obs, {}