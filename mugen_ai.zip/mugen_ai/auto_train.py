import os
import random
import subprocess
import time
import json
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import BaseCallback
from mugen_env import MugenEnv

EXCLUDE_CHARS = ["random", "sandbag", "boss_character"]
STATS_FILE = "stats.json"
ACTIVE_CHARS_FILE = "active_chars.json"
PIDS_FILE = "active_pids.json"
MAX_TIMESTEPS_PER_MATCH = 1000000 

def load_stats():
    if os.path.exists(STATS_FILE):
        try:
            with open(STATS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_stats(stats):
    try:
        temp = STATS_FILE + ".tmp"
        with open(temp, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=4, ensure_ascii=False)
        os.replace(temp, STATS_FILE)
    except:
        pass

def update_pid(instance_id, pid):
    # インスタンスごとに個別のファイルに書き込み、競合を避ける
    with open(f"pid_{instance_id}.txt", "w") as f:
        f.write(str(pid))

def get_active_chars():
    if os.path.exists(ACTIVE_CHARS_FILE):
        try:
            with open(ACTIVE_CHARS_FILE, "r") as f:
                return json.load(f)
        except:
            return []
    return []

def set_active_char(instance_id, char_name):
    active = get_active_chars()
    active = [item for item in active if item['id'] != instance_id]
    active.append({'id': instance_id, 'char': char_name})
    with open(ACTIVE_CHARS_FILE, "w") as f:
        json.dump(active, f)

def remove_active_char(instance_id):
    active = get_active_chars()
    active = [item for item in active if item['id'] != instance_id]
    with open(ACTIVE_CHARS_FILE, "w") as f:
        json.dump(active, f)
    
    # PIDファイルを削除
    pid_file = f"pid_{instance_id}.txt"
    if os.path.exists(pid_file):
        try: os.remove(pid_file)
        except: pass

class TrainCallback(BaseCallback):
    def __init__(self, model2=None, env2=None, verbose=0):
        super().__init__(verbose)
        self.model2 = model2
        self.env2 = env2
        self.obs2 = None
        if self.env2:
            try: self.obs2 = self.env2._get_obs()
            except: pass

    def _on_step(self) -> bool:
        # P2 Action (AIの場合)
        if self.model2 and self.env2:
            try:
                action2, _ = self.model2.predict(self.obs2, deterministic=True)
                self.env2._execute_command(action2)
                self.obs2 = self.env2._get_obs()
            except:
                pass
        
        # 試合終了(done)なら学習ループを抜ける
        if self.locals.get("dones")[0]:
            return False
        return True

def get_character_list():
    chars_dir = "chars"
    if not os.path.exists(chars_dir):
        return ["kfm"]
    all_chars = [d for d in os.listdir(chars_dir) if os.path.isdir(os.path.join(chars_dir, d))]
    return [c for c in all_chars if c not in EXCLUDE_CHARS]

if __name__ == "__main__":
    try:
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("--instance", type=int, default=0)
        parser.add_argument("--nosound", action="store_true", help="Mute MUGEN sound")
        args = parser.parse_args()
        
        print(f"[AutoTrain] Starting instance {args.instance}")
        os.makedirs("models", exist_ok=True)
        chars = get_character_list()
        stats = load_stats()
        
        while True:
            try:
                print(f"[AutoTrain] Starting new match loop...")
                mugen_process = None
                p1_char = "kfm"
                try:
                    stats = load_stats() # 最新の戦績をロード
                except:
                    pass
                active = [item['char'] for item in get_active_chars()]
                available = [c for c in chars if c not in active]
                if not available: available = chars
                
                # --- P1 Selection (Weighted by "Needs Training") ---
                p1_weights = []
                for c in available:
                    s = stats.get(c, {})
                    matches = s.get("matches", 0)
                    wins = s.get("wins", 0)
                    wr = wins / matches if matches > 0 else 0.0
                    
                    weight = 100.0
                    if matches < 5: weight += 500.0 # 新人ボーナス
                    if wr < 0.2: weight += 300.0    # 敗者復活ボーナス
                    if wr > 0.8: weight *= 0.5      # 強者ペナルティ
                    p1_weights.append(weight)
                
                p1_char = random.choices(available, weights=p1_weights, k=1)[0]
                set_active_char(args.instance, p1_char)
                
                # --- P2 Selection & AI vs AI Logic ---
                p2_candidates = [c for c in chars if c != p1_char]
                if not p2_candidates: p2_candidates = chars

                p1_stats = stats.get(p1_char, {})
                p1_matches = p1_stats.get("matches", 0)
                p1_rating = p1_stats.get("rating", 1500)
                
                # Match数が20を超えたら 50% の確率で AI vs AI
                is_ai_vs_ai = False
                if p1_matches >= 20 and random.random() < 0.5:
                    is_ai_vs_ai = True
                
                # 対戦相手決定 (レートが近い相手を選ぶ)
                p2_weights = []
                for c in p2_candidates:
                    s = stats.get(c, {})
                    r = s.get("rating", 1500)
                    diff = abs(p1_rating - r)
                    weight = 1.0 / (10.0 + diff) # レート差が小さいほど選ばれやすい
                    p2_weights.append(weight)
                
                if random.random() < 0.2:
                    p2_char = random.choice(p2_candidates) # 20%はランダム
                else:
                    p2_char = random.choices(p2_candidates, weights=p2_weights, k=1)[0]

                # モデルが存在しない場合は強制的にCPU戦にする
                if is_ai_vs_ai:
                    if not os.path.exists(f"models/{p2_char}_expert.zip"):
                        is_ai_vs_ai = False
                        print(f"[Instance {args.instance}] P2 model not found for {p2_char}. Reverting to CPU match.")

                # MUGEN起動設定
                p2_ai_level = "0" if is_ai_vs_ai else "4" # AI戦ならレベル0(操作なし)、CPU戦ならレベル4
                
                print(f"[Instance {args.instance}] Launching: {p1_char} (R:{p1_rating:.0f}) vs {p2_char} [{'AI' if is_ai_vs_ai else 'CPU'}]")
                
                cmd = [
                    "mugen.exe", "-p1", p1_char, "-p2", p2_char, 
                    "-p1.ai", "0", "-p2.ai", p2_ai_level, "-rounds", "1"
                ]
                if args.nosound:
                    cmd.append("-nosound")
                
                mugen_process = subprocess.Popen(cmd)
                update_pid(args.instance, mugen_process.pid)
                
                # ... (中略) ...
                
                # 環境構築
                # P1は常に学習対象
                try:
                    env1 = MugenEnv(player_side=1, process_id=mugen_process.pid, instance_id=args.instance)
                    vec_env1 = DummyVecEnv([lambda: env1])
                except Exception as e:
                    print(f"[Instance {args.instance}] Failed to initialize P1 env: {e}")
                    mugen_process.kill()
                    continue
                
                # P2がAIの場合の環境構築
                model2 = None
                env2 = None
                if is_ai_vs_ai:
                    try:
                        # P2用環境: instance_idを変えてキー入力の競合を防ぐ
                        # player_side=2 を指定することで、P2のアドレスを読みに行く
                        # ★重要: Versus Modeと同じように、少し待ってから初期化する
                        time.sleep(2.0) 
                        env2 = MugenEnv(player_side=2, process_id=mugen_process.pid, instance_id=args.instance + 1000)
                        
                        path2 = f"models/{p2_char}_expert.zip"
                        if os.path.exists(path2):
                            # P2モデルもCPUで動かす
                            model2 = PPO.load(path2, device='cpu')
                            print(f"[Instance {args.instance}] Loaded Opponent AI: {p2_char}")
                    except Exception as e:
                        print(f"[Instance {args.instance}] Failed to load Opponent AI: {e}, reverting to CPU.")
                        is_ai_vs_ai = False
                        model2 = None
                        env2 = None

                # ... (モデル読み込み処理) ...
                model_path = f"models/{p1_char}_expert.zip"
                policy_kwargs = dict(net_arch=[512, 512, 256])
                
                model = None
                if os.path.exists(model_path):
                    try:
                        model = PPO.load(model_path, env=vec_env1, device='cpu')
                        print(f"[Instance {args.instance}] Loaded existing model for {p1_char}")
                    except Exception as e:
                        print(f"[Instance {args.instance}] Architecture mismatch or corrupt file. Starting fresh: {e}")
                
                if model is None:
                    model = PPO("MlpPolicy", vec_env1, verbose=0, learning_rate=0.0003, 
                                policy_kwargs=policy_kwargs, device='cpu')
                    print(f"[Instance {args.instance}] Created new model with enhanced architecture for {p1_char}")

                # 学習実行 (Stable Baselines 3 の learn メソッドを使用)
                # これにより、試合中の経験がモデルにフィードバックされ、学習が進みます。
                try:
                    callback = TrainCallback(model2=model2, env2=env2)
                    model.learn(total_timesteps=MAX_TIMESTEPS_PER_MATCH, callback=callback, reset_num_timesteps=False)
                except Exception as e:
                    print(f"[Instance {args.instance}] Learning error: {e}")
                
                # 試合終了後の勝敗判定
                try:
                    final_my_life = vec_env1.envs[0].prev_my_life
                    final_opp_life = vec_env1.envs[0].prev_opp_life
                    is_win = final_my_life > final_opp_life
                except:
                    is_win = False
                
                # モデル保存
                try:
                    model.save(model_path)
                except:
                    pass
                        
                # ... (保存処理) ...
                
                # レート計算 (Elo Rating)
                K = 32 # 変動係数
                p2_rating = stats.get(p2_char, {}).get("rating", 1500)
                
                # 勝率の期待値
                ea_p1 = 1 / (1 + 10 ** ((p2_rating - p1_rating) / 400))
                ea_p2 = 1 / (1 + 10 ** ((p1_rating - p2_rating) / 400))
                
                # 実際のスコア
                sa_p1 = 1 if is_win else 0
                sa_p2 = 0 if is_win else 1
                
                # レート更新
                new_p1_rating = p1_rating + K * (sa_p1 - ea_p1)
                new_p2_rating = p2_rating + K * (sa_p2 - ea_p2)
                
                # 統計更新 (最新のデータをロードしてマージ)
                try:
                    current_stats = load_stats()
                    
                    # P1更新
                    if p1_char not in current_stats: 
                        current_stats[p1_char] = {"matches": 0, "wins": 0, "losses": 0, "timesteps": 0, "rating": 1500}
                    
                    current_stats[p1_char]["matches"] += 1
                    if is_win: current_stats[p1_char]["wins"] += 1
                    else: current_stats[p1_char]["losses"] += 1
                    # num_timesteps は累積値なので、そのまま代入するか、増分を足す必要がある
                    # ここでは単純に最新の累積値を反映
                    current_stats[p1_char]["timesteps"] = model.num_timesteps
                    current_stats[p1_char]["rating"] = new_p1_rating
                    
                    # P2更新 (AI戦だった場合)
                    if is_ai_vs_ai:
                        if p2_char not in current_stats: 
                            current_stats[p2_char] = {"matches": 0, "wins": 0, "losses": 0, "timesteps": 0, "rating": 1500}
                        current_stats[p2_char]["matches"] += 1
                        if not is_win: current_stats[p2_char]["wins"] += 1
                        else: current_stats[p2_char]["losses"] += 1
                        current_stats[p2_char]["rating"] = new_p2_rating
                    
                    save_stats(current_stats)
                    print(f"[Result] {p1_char} ({new_p1_rating:.0f}) {'WIN' if is_win else 'LOSE'} vs {p2_char}")
                except Exception as e:
                    print(f"[Instance {args.instance}] Stats update error: {e}")

            except Exception as e:
                print(f"[Instance {args.instance}] ERROR: {e}")
                time.sleep(5)
            finally:
                if mugen_process:
                    try: mugen_process.kill()
                    except: pass
                remove_active_char(args.instance)
                time.sleep(2)
    except Exception as e:
        print(f"[AutoTrain] CRITICAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        time.sleep(30)
