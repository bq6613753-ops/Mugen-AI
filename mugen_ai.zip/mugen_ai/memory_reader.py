import pymem
import re
import time
import ctypes
from ctypes import wintypes

class MugenMemoryReader:
    def __init__(self, process_id=None):
        self.process_id = process_id
        self.pm = None
        self.p1_base = None
        self.p2_base = None
        
        self.offsets = {
            'life': 0,
            'power': -356,
            'x': 68,
            'y': 76,
            'state': 520,
            'timer': 264
        }

    def _attach(self):
        # MUGENが起動直後だとアタッチに失敗することがあるため、リトライを行う
        for _ in range(10):
            try:
                if self.process_id:
                    self.pm = pymem.Pymem(self.process_id)
                else:
                    self.pm = pymem.Pymem("mugen.exe")
                return True
            except:
                time.sleep(1)
        return False

    def _scan_all_lives(self):
        if not self.pm: return []
        found_addresses = []
        kernel32 = ctypes.windll.kernel32
        
        class MEMORY_BASIC_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("BaseAddress", ctypes.c_void_p),
                ("AllocationBase", ctypes.c_void_p),
                ("AllocationProtect", wintypes.DWORD),
                ("RegionSize", ctypes.c_size_t),
                ("State", wintypes.DWORD),
                ("Protect", wintypes.DWORD),
                ("Type", wintypes.DWORD),
            ]
        
        address = 0
        mbi = MEMORY_BASIC_INFORMATION()
        pattern = b"\x01\x00\x00\x00\x00\x00\x00\x00"
        
        while kernel32.VirtualQueryEx(self.pm.process_handle, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)):
            if mbi.State == 0x1000 and (mbi.Protect == 0x04 or mbi.Protect == 0x40):
                try:
                    # 巨大なリージョンは分割して読み取るか、スキップして安定性を高める
                    if mbi.RegionSize > 10 * 1024 * 1024: # 10MB以上は怪しい
                        address += mbi.RegionSize
                        continue
                    buffer = self.pm.read_bytes(mbi.BaseAddress, mbi.RegionSize)
                    for match in re.finditer(re.escape(pattern), buffer):
                        match_address = mbi.BaseAddress + match.start() + 8
                        if match.start() + 8 + 16 <= len(buffer):
                            val1 = int.from_bytes(buffer[match.start()+8 : match.start()+12], 'little', signed=True)
                            val2 = int.from_bytes(buffer[match.start()+12 : match.start()+16], 'little', signed=True)
                            val3 = int.from_bytes(buffer[match.start()+16 : match.start()+20], 'little', signed=True)
                            val4 = int.from_bytes(buffer[match.start()+20 : match.start()+24], 'little', signed=True)
                            
                            if val1 == val2 == val3 == val4 and 100 <= val1 <= 5000: # 体力として妥当な範囲
                                found_addresses.append(match_address)
                except:
                    pass
            address += mbi.RegionSize
        return found_addresses

    def scan_and_lock(self, timeout=60):
        print(f"Waiting for MUGEN (PID: {self.process_id}) to stabilize...")
        if not self._attach():
            raise Exception(f"Could not attach to MUGEN process {self.process_id}")
            
        print(f"Scanning for character data (Timeout: {timeout}s)...")
        start_scan = time.time()
        while True:
            if time.time() - start_scan > timeout:
                raise Exception("Timeout scanning for character data. Character might be incompatible or loading failed.")
            
            addresses = self._scan_all_lives()
            if len(addresses) >= 2:
                addresses.sort()
                self.p1_base = addresses[0]
                self.p2_base = addresses[1]
                print(f"Locked P1 Base: {hex(self.p1_base)} | P2 Base: {hex(self.p2_base)}")
                break
            time.sleep(2)

    def get_player_state(self, player=1):
        base = self.p1_base if player == 1 else self.p2_base
        if not base or not self.pm:
            return None
            
        try:
            # 読み取り失敗時にクラッシュしないよう個別に保護
            return {
                'life': self.pm.read_int(base + self.offsets['life']),
                'power': self.pm.read_int(base + self.offsets['power']),
                'x': self.pm.read_float(base + self.offsets['x']),
                'y': self.pm.read_float(base + self.offsets['y']),
                'state': self.pm.read_int(base + self.offsets['state']),
                'timer': self.pm.read_int(base + self.offsets['timer'])
            }
        except Exception:
            # 失敗した場合はNoneを返し、呼び出し側で安全に処理させる
            return None

    def is_match_over(self):
        try:
            p1 = self.get_player_state(1)
            p2 = self.get_player_state(2)
            if not p1 or not p2:
                return False # 読み取り失敗時は「継続中」として扱う(安定重視)
            
            # 体力が異常値(ゴミデータ)でないことも確認
            p1_dead = p1['life'] <= 0 or p1['life'] > 10000
            p2_dead = p2['life'] <= 0 or p2['life'] > 10000
            return p1_dead or p2_dead
        except:
            return False