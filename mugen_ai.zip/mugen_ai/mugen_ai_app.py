import tkinter as tk
from tkinter import ttk
import json
import os
import threading
import subprocess
import time
import cv2
import numpy as np
import mss
import win32gui
import math
from PIL import Image, ImageTk

STATS_FILE = "stats.json"

class MugenAIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("MUGEN AI Control Center")
        self.root.geometry("1200x750")
        self.root.configure(bg="#121212")
        
        self.training_processes = []
        self.is_training = False
        
        # Cleanup temp files on start
        for f in ["active_chars.json", "active_pids.json"]:
            if os.path.exists(f): os.remove(f)
        
        self._setup_style()
        self._create_widgets()
        
        self.update_dashboard()
        self.update_viewer()

    def _setup_style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", background="#1e1e1e", foreground="white", fieldbackground="#1e1e1e", rowheight=30)
        style.configure("Treeview.Heading", background="#333333", foreground="white", font=('Arial', 10, 'bold'))
        style.map("Treeview", background=[('selected', '#2e7d32')])

    def _create_widgets(self):
        # メインのタブ作成
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # --- Training Tab ---
        self.train_tab = tk.Frame(self.notebook, bg="#121212")
        self.notebook.add(self.train_tab, text=" TRAINING ")
        
        self.paned = tk.PanedWindow(self.train_tab, orient=tk.HORIZONTAL, bg="#121212", borderwidth=0)
        self.paned.pack(fill=tk.BOTH, expand=True)

        self.left_frame = tk.Frame(self.paned, bg="#121212", padx=10, pady=10)
        self.paned.add(self.left_frame, width=450)
        
        tk.Label(self.left_frame, text="Character Stats (Ranked by Win Rate)", font=("Arial", 14, "bold"), bg="#121212", fg="#4caf50").pack(anchor="w", pady=(0, 10))
        
        columns = ("Character", "Rating", "Matches", "Win Rate", "Steps")
        self.tree = ttk.Treeview(self.left_frame, columns=columns, show="headings")
        for col in columns:
            # ヘッダーをクリックでソート
            self.tree.heading(col, text=col, command=lambda c=col: self._sort_tree(c, False))
            self.tree.column(col, width=80, anchor="center")
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        # ダブルクリックでP1、右クリックでP2に設定するショートカット
        self.tree.bind("<Double-1>", self._on_tree_double_click)
        self.tree.bind("<Button-3>", self._on_tree_right_click)
        
        tk.Label(self.left_frame, text="Tip: Double-click to set P1, Right-click to set P2", 
                 font=("Arial", 8), bg="#121212", fg="#666666").pack(pady=5)

        self.right_frame = tk.Frame(self.paned, bg="#121212", padx=10, pady=10)
        self.paned.add(self.right_frame)
        
        self.btn_frame = tk.Frame(self.right_frame, bg="#121212")
        self.btn_frame.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(self.btn_frame, text="Instances:", bg="#121212", fg="white").pack(side=tk.LEFT, padx=5)
        self.instance_count_var = tk.StringVar(value="4")
        self.instance_spin = tk.Spinbox(self.btn_frame, from_=1, to=32, width=5, textvariable=self.instance_count_var, bg="#333333", fg="white", insertbackground="white")
        self.instance_spin.pack(side=tk.LEFT, padx=5)

        self.mute_train_var = tk.BooleanVar(value=True)
        self.mute_train_check = tk.Checkbutton(self.btn_frame, text="Mute Sound", variable=self.mute_train_var, 
                                              bg="#121212", fg="white", selectcolor="#333333", activebackground="#121212", activeforeground="white")
        self.mute_train_check.pack(side=tk.LEFT, padx=10)

        self.start_btn = tk.Button(self.btn_frame, text="START TRAINING", command=self.toggle_training, 
                                   bg="#2e7d32", fg="white", font=("Arial", 12, "bold"), padx=20, pady=10, relief=tk.FLAT)
        self.start_btn.pack(side=tk.LEFT, padx=10)
        
        self.status_label = tk.Label(self.btn_frame, text="Status: IDLE", bg="#121212", fg="#999999", font=("Arial", 10))
        self.status_label.pack(side=tk.LEFT, padx=20)

        tk.Label(self.right_frame, text="Live Monitoring (Stats Only)", font=("Arial", 14, "bold"), bg="#121212", fg="#2196f3").pack(anchor="w", pady=10)
        # キャプチャ画面は廃止しました
        self.log_text = tk.Text(self.right_frame, bg="#000000", fg="#00ff00", height=15, font=("Consolas", 10))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.insert(tk.END, "System Ready.\n")

        # --- Versus Tab ---
        self.vs_tab = tk.Frame(self.notebook, bg="#121212", padx=20, pady=20)
        self.notebook.add(self.vs_tab, text=" VERSUS MODE ")
        
        tk.Label(self.vs_tab, text="Play vs AI or Watch AI vs AI", font=("Arial", 18, "bold"), bg="#121212", fg="#ff9800").pack(pady=20)
        
        self.vs_config_frame = tk.Frame(self.vs_tab, bg="#1e1e1e", padx=20, pady=20)
        self.vs_config_frame.pack(fill=tk.X)
        
        # P1 Config
        p1_frame = tk.LabelFrame(self.vs_config_frame, text="PLAYER 1 (Left)", bg="#1e1e1e", fg="white", padx=10, pady=10)
        p1_frame.grid(row=0, column=0, padx=10, sticky="nsew")
        tk.Label(p1_frame, text="Character:", bg="#1e1e1e", fg="#999999").pack(anchor="w")
        self.p1_char_var = tk.StringVar(value="kfm")
        self.p1_char_entry = tk.Entry(p1_frame, textvariable=self.p1_char_var, bg="#333333", fg="white")
        self.p1_char_entry.pack(fill=tk.X, pady=5)
        tk.Label(p1_frame, text="Control:", bg="#1e1e1e", fg="#999999").pack(anchor="w")
        self.p1_type_var = tk.StringVar(value="Human")
        ttk.Combobox(p1_frame, textvariable=self.p1_type_var, values=["Human", "AI", "CPU"]).pack(fill=tk.X)

        # VS Label
        tk.Label(self.vs_config_frame, text="VS", font=("Arial", 24, "bold"), bg="#1e1e1e", fg="white").grid(row=0, column=1, padx=20)

        # P2 Config
        p2_frame = tk.LabelFrame(self.vs_config_frame, text="PLAYER 2 (Right)", bg="#1e1e1e", fg="white", padx=10, pady=10)
        p2_frame.grid(row=0, column=2, padx=10, sticky="nsew")
        tk.Label(p2_frame, text="Character:", bg="#1e1e1e", fg="#999999").pack(anchor="w")
        self.p2_char_var = tk.StringVar(value="kfm")
        self.p2_char_entry = tk.Entry(p2_frame, textvariable=self.p2_char_var, bg="#333333", fg="white")
        self.p2_char_entry.pack(fill=tk.X, pady=5)
        tk.Label(p2_frame, text="Control:", bg="#1e1e1e", fg="#999999").pack(anchor="w")
        self.p2_type_var = tk.StringVar(value="AI")
        ttk.Combobox(p2_frame, textvariable=self.p2_type_var, values=["Human", "AI", "CPU"]).pack(fill=tk.X)

        self.mute_vs_var = tk.BooleanVar(value=False)
        self.mute_vs_check = tk.Checkbutton(self.vs_tab, text="Mute Sound (無音で起動する)", variable=self.mute_vs_var,
                                           bg="#121212", fg="white", selectcolor="#333333", activebackground="#121212", activeforeground="white")
        self.mute_vs_check.pack(pady=5)

        self.vs_start_btn = tk.Button(self.vs_tab, text="LAUNCH VERSUS MATCH", command=self.start_versus,
                                      bg="#ff9800", fg="white", font=("Arial", 14, "bold"), padx=40, pady=15, relief=tk.FLAT)
        self.vs_start_btn.pack(pady=30)
        
        tk.Label(self.vs_tab, text="""Controls:
1P: WASD + J,K,L,U,I,O
2P: Arrows + Numpad 1-6""", 
                 bg="#121212", fg="#666666", justify=tk.LEFT).pack()

    def start_versus(self):
        p1 = self.p1_char_var.get()
        p2 = self.p2_char_var.get()
        t1 = self.p1_type_var.get()
        t2 = self.p2_type_var.get()
        
        cmd = ["python", "versus_mode.py", "--p1", p1, "--p2", p2, "--t1", t1, "--t2", t2]
        if self.mute_vs_var.get():
            cmd.append("--nosound")
            
        # versus_mode.py を起動
        subprocess.Popen(cmd)

    def _sort_tree(self, col, reverse):
        l = [(self.tree.set(k, col), k) for k in self.tree.get_children('')]
        
        # 数値の場合は数値としてソート
        try:
            if col in ["Matches", "Steps"]:
                l.sort(key=lambda t: int(t[0]), reverse=reverse)
            elif col == "Win Rate":
                l.sort(key=lambda t: float(t[0].replace('%', '')), reverse=reverse)
            else:
                l.sort(reverse=reverse)
        except:
            l.sort(reverse=reverse)

        for index, (val, k) in enumerate(l):
            self.tree.move(k, '', index)

        # 次回クリック時は逆順にする
        self.tree.heading(col, command=lambda: self._sort_tree(col, not reverse))

    def _on_tree_double_click(self, event):
        item = self.tree.selection()
        if item:
            char_name = self.tree.item(item, "values")[0]
            self.p1_char_var.set(char_name)
            self.notebook.select(self.vs_tab) # Versusタブへ移動

    def _on_tree_right_click(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            char_name = self.tree.item(item, "values")[0]
            self.p2_char_var.set(char_name)
            self.notebook.select(self.vs_tab) # Versusタブへ移動

    def toggle_training(self):
        if not self.is_training:
            try:
                count = int(self.instance_count_var.get())
            except:
                count = 4
            
            self.is_training = True
            self.start_btn.config(text="STOP ALL", bg="#c62828")
            self.status_label.config(text=f"Status: {count}x TRAINING...", fg="#4caf50")
            self.instance_spin.config(state="disabled")
            self.mute_train_check.config(state="disabled")
            
            for i in range(count):
                cmd = ["python", "auto_train.py", "--instance", str(i)]
                if self.mute_train_var.get():
                    cmd.append("--nosound")
                p = subprocess.Popen(cmd)
                self.training_processes.append(p)
        else:
            self.is_training = False
            self.start_btn.config(text="START TRAINING", bg="#2e7d32")
            self.status_label.config(text="Status: IDLE", fg="#999999")
            self.instance_spin.config(state="normal")
            self.mute_train_check.config(state="normal")
            for p in self.training_processes:
                p.terminate()
            self.training_processes = []
            os.system("taskkill /f /im mugen.exe >nul 2>&1")
            for f in ["active_chars.json", "active_pids.json"]:
                if os.path.exists(f): os.remove(f)

    def update_dashboard(self):
        if os.path.exists(STATS_FILE):
            try:
                with open(STATS_FILE, "r", encoding="utf-8") as f:
                    stats = json.load(f)
                for row in self.tree.get_children():
                    self.tree.delete(row)
                
                # 勝率でランキング（降順）
                def calc_wr(data):
                    m = data.get("matches", 0)
                    if m == 0: return 0
                    return data.get("wins", 0) / m

                # 勝率 > 試合数 の順でソート
                sorted_stats = sorted(stats.items(), key=lambda x: (calc_wr(x[1]), x[1].get("matches", 0)), reverse=True)
                
                for char, data in sorted_stats:
                    m = data.get("matches", 0)
                    w = data.get("wins", 0)
                    r = data.get("rating", 1500)
                    wr_val = calc_wr(data)
                    wr_str = f"{(wr_val*100):.1f}%"
                    s = f"{data.get('timesteps', 0):,}"
                    self.tree.insert("", "end", values=(char, int(r), m, wr_str, s))
            except:
                pass
        self.root.after(3000, self.update_dashboard)

    def update_viewer(self):
        # Versus Modeの時だけキャプチャを有効にする
        # pid_versus.txt が存在するかチェック
        if os.path.exists("pid_versus.txt"):
            try:
                with open("pid_versus.txt", "r") as f:
                    pid = int(f.read().strip())
                
                with mss.mss() as sct:
                    # PIDからウィンドウを探してキャプチャ (簡易実装)
                    # ※実際にはPIDからHWNDを特定する処理が必要だが、ここでは全画面キャプチャで代用
                    # もしくはMUGENがアクティブであることを前提にスクリーンショット
                    monitor = sct.monitors[1] # メインモニタ
                    img = np.array(sct.grab(monitor))
                    img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
                    
                    # 画面サイズに合わせてリサイズ
                    h, w = img.shape[:2]
                    scale = min(800/w, 600/h)
                    img = cv2.resize(img, (int(w*scale), int(h*scale)))
                    
                    img_pil = Image.fromarray(img)
                    img_tk = ImageTk.PhotoImage(img_pil)
                    self.viewer_label.config(image=img_tk)
                    self.viewer_label.image = img_tk
            except:
                pass
        
        self.root.after(100, self.update_viewer)

if __name__ == "__main__":
    root = tk.Tk()
    app = MugenAIApp(root)
    root.mainloop()