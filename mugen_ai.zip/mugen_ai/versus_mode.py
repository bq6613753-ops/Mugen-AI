import os
import argparse
import subprocess
import time
from stable_baselines3 import PPO
from mugen_env import MugenEnv

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--p1", type=str, default="kfm")
    parser.add_argument("--p2", type=str, default="kfm")
    parser.add_argument("--t1", type=str, default="Human") # Human, AI, CPU
    parser.add_argument("--t2", type=str, default="AI")
    parser.add_argument("--nosound", action="store_true", help="Mute MUGEN sound")
    args = parser.parse_args()

    # MUGEN起動引数
    p1_ai = "0" if args.t1 == "Human" else "1"
    p2_ai = "0" if args.t2 == "Human" else "1"
    
    # CPU(MUGEN標準AI)の場合はレベルを設定
    if args.t1 == "CPU": p1_ai = "8"
    if args.t2 == "CPU": p2_ai = "8"

    # MUGEN起動
    cmd = [
        "mugen.exe", 
        "-p1", args.p1, "-p2", args.p2,
        "-p1.ai", p1_ai, "-p2.ai", p2_ai,
        "-rounds", "2"
    ]
    if args.nosound:
        cmd.append("-nosound")
    
    mugen_process = subprocess.Popen(cmd)
    
    # PIDを保存 (キャプチャ用)
    with open("pid_versus.txt", "w") as f:
        f.write(str(mugen_process.pid))
    
    time.sleep(5)
    
    # AI制御が必要なプレイヤーの環境をセットアップ
    envs = []
    models = []
    
    if args.t1 == "AI":
        env1 = MugenEnv(player_side=1, process_id=mugen_process.pid, instance_id=99)
        path1 = f"models/{args.p1}_expert.zip"
        if os.path.exists(path1):
            model1 = PPO.load(path1)
            envs.append(env1)
            models.append(model1)
            print(f"P1 AI Loaded: {args.p1}")

    if args.t2 == "AI":
        env2 = MugenEnv(player_side=2, process_id=mugen_process.pid, instance_id=100)
        path2 = f"models/{args.p2}_expert.zip"
        if os.path.exists(path2):
            model2 = PPO.load(path2)
            envs.append(env2)
            models.append(model2)
            print(f"P2 AI Loaded: {args.p2}")

    print("Versus Match Started! (Press Ctrl+C to exit)")
    
    try:
        while True:
            # MUGENが終了していたらループを抜ける
            if mugen_process.poll() is not None:
                print("MUGEN process ended.")
                break

            try:
                for env, model in zip(envs, models):
                    try:
                        # エラーが起きても無視して継続する (効率より安定性重視)
                        obs = env._get_obs()
                        action, _ = model.predict(obs, deterministic=True)
                        env._execute_command(action)
                    except Exception:
                        pass # 一時的な読み取りエラーなどは完全に無視
            except Exception:
                pass # ループ全体のエラーも無視
                
            time.sleep(0.016) # 60FPS
            
    except KeyboardInterrupt:
        print("Stopping versus mode...")
    except Exception as e:
        print(f"Critical Error: {e}")
    finally:
        if mugen_process: mugen_process.kill()
        if os.path.exists("pid_versus.txt"): os.remove("pid_versus.txt")

if __name__ == "__main__":
    main()